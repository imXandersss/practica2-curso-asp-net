using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SegundaPracticaCursoaspnet.Pages
{
    public class NominaModel : PageModel
    {
        public List<DatosEmpleados> Employed = new List<DatosEmpleados>();

        public void OnGet()
        {
            Employed.Add(new DatosEmpleados
            {
                nombre = "Bryan",
                apellido = "Bocio",
                Cargo = "Desarrollador",
                Salario = 75000,
                DescuentoAFP = 0,
                DescuentoARS=0,
                DescuentoISR=0,
                TotalDescuento=0,
                SalarioNeto=0,


                


            });
            Employed.Add(new DatosEmpleados {
                nombre="Jos�",
                apellido="Montero",
                Cargo="Gerente",
                Salario=100000,
                DescuentoAFP = 0,
                DescuentoARS = 0,
                DescuentoISR = 0,
                TotalDescuento = 0,
                SalarioNeto = 0
            });



            Employed.Add(new DatosEmpleados{
                nombre="Johanny",
                apellido="Saona",
                Cargo="Compras",
                Salario=80000,
                DescuentoAFP = 0,
                DescuentoARS = 0,
                DescuentoISR = 0,
                TotalDescuento = 0,
                SalarioNeto = 0,




            });
            Employed.Add(new DatosEmpleados{
                nombre="Andr�s",
                apellido="Castillo",
                Cargo="Subgerente",
                Salario=900000,
                DescuentoAFP = 0,
                DescuentoARS = 0,
                DescuentoISR = 0,
                TotalDescuento = 0,
                SalarioNeto = 0,



            });
            Employed.Add(new DatosEmpleados{
                nombre="Justine",
                apellido="Sena",
                Cargo="Redes",
                Salario=50000,
                DescuentoAFP = 0,
                DescuentoARS = 0,
                DescuentoISR = 0,
                TotalDescuento = 0,
                SalarioNeto = 0,
            });
            foreach (var item in Employed)
            {
                item.DescuentoAFP=AFP(item.Salario);
                item.DescuentoARS = ARS(item.Salario);
                item.DescuentoISR = ISR(item.Salario);
                item.TotalDescuento = TotalDescuento(item.DescuentoAFP, item.DescuentoARS, item.DescuentoISR);
                item.SalarioNeto = SueldoNeto(item.Salario, item.DescuentoAFP, item.DescuentoARS, item.DescuentoISR);
            }
           
        }
        private double AFP(double salario)
        {
            double AFP = salario * 0.0287;

            if (AFP > 7738.67)
            {
                AFP = 7738.67;
            }

            return AFP;
        }
        private double ARS(double salario)
        {
            double ARS=salario * 0.0304;

            if (ARS > 4098.53)
            {
                ARS = 4098.53;
            }
            return ARS;
        }
        private double ISR(double salario)
        {
            double anual = salario * 12;
            double isr = 0;
            if( anual > 0 && anual < 416220)
            {
                isr = 0;
            }
            else if(anual > 416220 && anual < 624329.01)
            {
                isr = salario * 0.15;
            }
            return isr;   
        }
        private double TotalDescuento(double afp, double ars, double isr)
        {
            double descuento = afp + ars + isr;

            return descuento;
        }
        private double SueldoNeto(double salario,double afp, double ars, double isr)
        {
            double descuento = salario - afp - ars - isr;

            return descuento;
        }




    }
    public class DatosEmpleados
    {
        public string nombre;
        public string apellido;
        public string Cargo;
        public double Salario;
        public double DescuentoAFP;
        public double DescuentoARS;
        public double DescuentoISR;
        public double TotalDescuento;
        public double SalarioNeto;
    }

}



